from . import spycy

spycy.main()
