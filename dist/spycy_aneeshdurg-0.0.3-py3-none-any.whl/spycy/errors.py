class ExecutionError(Exception):
    pass
